/**
 * NRG-UA Main JavaScript
 * Handles animations, interactions, and dynamic features
 */

// ============================================
// Utility Functions
// ============================================

const utils = {
    // Debounce function for performance
    debounce(func, wait = 100) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Throttle function for scroll events
    throttle(func, limit = 100) {
        let inThrottle;
        return function executedFunction(...args) {
            if (!inThrottle) {
                func(...args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    // Check if element is in viewport
    isInViewport(element, offset = 0) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight - offset) &&
            rect.bottom >= offset
        );
    },

    // Animate number counting
    animateCounter(element, target, duration = 2000) {
        const start = 0;
        const startTime = performance.now();
        
        const updateCounter = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function (ease-out-cubic)
            const easeOut = 1 - Math.pow(1 - progress, 3);
            const current = Math.floor(start + (target - start) * easeOut);
            
            element.textContent = current.toLocaleString('uk-UA');
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            }
        };
        
        requestAnimationFrame(updateCounter);
    }
};

// ============================================
// Preloader
// ============================================

class Preloader {
    constructor() {
        this.preloader = document.getElementById('preloader');
        this.init();
    }

    init() {
        if (!this.preloader) return;

        window.addEventListener('load', () => {
            setTimeout(() => {
                this.hide();
            }, 500);
        });

        // Fallback - hide after 3 seconds
        setTimeout(() => {
            this.hide();
        }, 3000);
    }

    hide() {
        this.preloader.classList.add('hidden');
        document.body.style.overflow = '';
    }
}

// ============================================
// Header
// ============================================

class Header {
    constructor() {
        this.header = document.getElementById('header');
        this.mobileToggle = document.getElementById('mobileToggle');
        this.mainNav = document.getElementById('mainNav');
        this.lastScrollY = 0;
        this.ticking = false;

        this.init();
    }

    init() {
        if (!this.header) return;

        // Scroll handling
        window.addEventListener('scroll', () => {
            if (!this.ticking) {
                requestAnimationFrame(() => {
                    this.onScroll();
                    this.ticking = false;
                });
                this.ticking = true;
            }
        });

        // Mobile menu toggle
        if (this.mobileToggle && this.mainNav) {
            this.mobileToggle.addEventListener('click', () => {
                this.toggleMobileMenu();
            });
        }

        // Close mobile menu on link click
        this.mainNav?.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        });

        // Close mobile menu on outside click
        document.addEventListener('click', (e) => {
            if (!this.header.contains(e.target) && this.mainNav?.classList.contains('active')) {
                this.closeMobileMenu();
            }
        });
    }

    onScroll() {
        const scrollY = window.scrollY;

        // Add scrolled class
        if (scrollY > 50) {
            this.header.classList.add('scrolled');
        } else {
            this.header.classList.remove('scrolled');
        }

        // Hide/show header on scroll (optional)
        if (scrollY > this.lastScrollY && scrollY > 500) {
            this.header.style.transform = 'translateY(-100%)';
        } else {
            this.header.style.transform = 'translateY(0)';
        }

        this.lastScrollY = scrollY;
    }

    toggleMobileMenu() {
        this.mobileToggle.classList.toggle('active');
        this.mainNav.classList.toggle('active');
        document.body.classList.toggle('menu-open');
    }

    closeMobileMenu() {
        this.mobileToggle?.classList.remove('active');
        this.mainNav?.classList.remove('active');
        document.body.classList.remove('menu-open');
    }
}

// ============================================
// Scroll Animations
// ============================================

class ScrollAnimations {
    constructor() {
        this.animatedElements = document.querySelectorAll('[data-animate]');
        this.init();
    }

    init() {
        if (this.animatedElements.length === 0) return;

        // Initial check
        this.checkElements();

        // Scroll handler
        window.addEventListener('scroll', utils.throttle(() => {
            this.checkElements();
        }, 50));

        // Resize handler
        window.addEventListener('resize', utils.debounce(() => {
            this.checkElements();
        }, 100));
    }

    checkElements() {
        this.animatedElements.forEach(element => {
            if (utils.isInViewport(element, 100) && !element.classList.contains('animated')) {
                const delay = element.dataset.delay || 0;
                setTimeout(() => {
                    element.classList.add('animated');
                }, parseInt(delay));
            }
        });
    }
}

// ============================================
// Stats Counter
// ============================================

class StatsCounter {
    constructor() {
        this.counters = document.querySelectorAll('[data-count]');
        this.animated = false;
        this.init();
    }

    init() {
        if (this.counters.length === 0) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animated) {
                    this.animated = true;
                    this.animateCounters();
                }
            });
        }, { threshold: 0.5 });

        const statsSection = document.querySelector('.hero-stats');
        if (statsSection) {
            observer.observe(statsSection);
        }
    }

    animateCounters() {
        this.counters.forEach((counter, index) => {
            const target = parseInt(counter.dataset.count);
            setTimeout(() => {
                utils.animateCounter(counter, target, 2000);
            }, index * 200);
        });
    }
}

// ============================================
// Ukraine Map
// ============================================

class UkraineMap {
    constructor() {
        this.map = document.getElementById('ukraineMap');
        this.tooltip = document.getElementById('mapTooltip');
        this.points = null;

        // Branch data
        this.branches = {
            'Київ': {
                type: 'Головний офіс',
                address: 'вул. Хрещатик, 1',
                phone: '+38 (044) 123-45-67'
            },
            'Львів': {
                type: 'Регіональний офіс',
                address: 'вул. Городоцька, 50',
                phone: '+38 (032) 123-45-67'
            },
            'Одеса': {
                type: 'Регіональний офіс',
                address: 'вул. Дерибасівська, 10',
                phone: '+38 (048) 123-45-67'
            },
            'Дніпро': {
                type: 'Регіональний офіс',
                address: 'просп. Яворницького, 100',
                phone: '+38 (056) 123-45-67'
            },
            'Харків': {
                type: 'Логістичний центр',
                address: 'вул. Полтавський Шлях, 150',
                phone: '+38 (057) 123-45-67'
            },
            'Вінниця': {
                type: 'Регіональний офіс',
                address: 'вул. Соборна, 25',
                phone: '+38 (043) 123-45-67'
            },
            'Запоріжжя': {
                type: 'Склад',
                address: 'просп. Соборний, 200',
                phone: '+38 (061) 123-45-67'
            },
            'Бровари': {
                type: 'Центральний склад',
                address: 'вул. Промислова, 15',
                phone: '+38 (044) 123-45-68'
            }
        };

        this.init();
    }

    init() {
        if (!this.map) return;

        this.points = this.map.querySelectorAll('.branch-point');
        
        // Add event listeners to points
        this.points.forEach(point => {
            point.addEventListener('mouseenter', (e) => this.showTooltip(e, point));
            point.addEventListener('mouseleave', () => this.hideTooltip());
            point.addEventListener('click', (e) => this.onPointClick(e, point));
        });

        // Animate points on scroll
        this.animatePoints();

        // Draw connection lines
        this.drawConnections();
    }

    showTooltip(e, point) {
        const city = point.dataset.city;
        const branch = this.branches[city];

        if (!branch || !this.tooltip) return;

        // Update tooltip content
        this.tooltip.querySelector('.tooltip-city').textContent = city;
        this.tooltip.querySelector('.tooltip-type').textContent = branch.type;
        this.tooltip.querySelector('.tooltip-address').textContent = branch.address;

        // Position tooltip
        const rect = point.getBoundingClientRect();
        const mapRect = this.map.getBoundingClientRect();
        
        this.tooltip.style.left = `${rect.left - mapRect.left + rect.width / 2}px`;
        this.tooltip.style.top = `${rect.top - mapRect.top - 10}px`;
        this.tooltip.style.transform = 'translate(-50%, -100%)';

        // Show tooltip
        this.tooltip.classList.add('active');
    }

    hideTooltip() {
        if (this.tooltip) {
            this.tooltip.classList.remove('active');
        }
    }

    onPointClick(e, point) {
        const city = point.dataset.city;
        // Could open modal or navigate to contact page
        console.log(`Clicked on ${city}`);
    }

    animatePoints() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.points.forEach((point, index) => {
                        setTimeout(() => {
                            point.classList.add('visible');
                            const pulse = point.querySelector('.point-pulse');
                            if (pulse) {
                                pulse.style.animation = 'point-pulse 3s ease-in-out infinite';
                                pulse.style.animationDelay = `${index * 0.2}s`;
                            }
                        }, index * 150);
                    });
                }
            });
        }, { threshold: 0.3 });

        const mapWrapper = document.querySelector('.ukraine-map-wrapper');
        if (mapWrapper) {
            observer.observe(mapWrapper);
        }
    }

    drawConnections() {
        const linesGroup = this.map?.querySelector('.connection-lines');
        if (!linesGroup || !this.points) return;

        // Get Kyiv (center) coordinates
        const kyivPoint = this.map.querySelector('[data-city="Київ"]');
        if (!kyivPoint) return;

        const kyivCircle = kyivPoint.querySelector('.point-core');
        const kyivX = parseFloat(kyivCircle.getAttribute('cx'));
        const kyivY = parseFloat(kyivCircle.getAttribute('cy'));

        // Create lines from Kyiv to other cities
        this.points.forEach(point => {
            if (point.dataset.city === 'Київ') return;

            const circle = point.querySelector('.point-core');
            const x = parseFloat(circle.getAttribute('cx'));
            const y = parseFloat(circle.getAttribute('cy'));

            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', kyivX);
            line.setAttribute('y1', kyivY);
            line.setAttribute('x2', x);
            line.setAttribute('y2', y);
            line.setAttribute('stroke', 'rgba(0, 212, 255, 0.2)');
            line.setAttribute('stroke-width', '1');
            line.setAttribute('stroke-dasharray', '5,5');
            line.classList.add('connection-line');

            linesGroup.appendChild(line);
        });

        // Animate lines
        this.animateLines();
    }

    animateLines() {
        const lines = this.map?.querySelectorAll('.connection-line');
        if (!lines) return;

        lines.forEach((line, index) => {
            const length = line.getTotalLength?.() || 200;
            line.style.strokeDasharray = length;
            line.style.strokeDashoffset = length;
            line.style.animation = `dash-line 1.5s ease forwards ${index * 0.1}s`;
        });

        // Add CSS animation
        if (!document.getElementById('map-line-animation')) {
            const style = document.createElement('style');
            style.id = 'map-line-animation';
            style.textContent = `
                @keyframes dash-line {
                    to {
                        stroke-dashoffset: 0;
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }
}

// ============================================
// Brands Marquee
// ============================================

class BrandsMarquee {
    constructor() {
        this.marquee = document.querySelector('.brands-marquee');
        this.init();
    }

    init() {
        if (!this.marquee) return;

        // Pause on hover
        const track = this.marquee.querySelector('.marquee-content');
        
        this.marquee.addEventListener('mouseenter', () => {
            if (track) track.style.animationPlayState = 'paused';
        });

        this.marquee.addEventListener('mouseleave', () => {
            if (track) track.style.animationPlayState = 'running';
        });
    }
}

// ============================================
// Language Switcher
// ============================================

class LanguageSwitcher {
    constructor() {
        this.buttons = document.querySelectorAll('.lang-btn');
        this.currentLang = localStorage.getItem('nrg-lang') || 'uk';
        this.init();
    }

    init() {
        if (this.buttons.length === 0) return;

        // Set initial state
        this.setActiveLang(this.currentLang);

        // Add click handlers
        this.buttons.forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.dataset.lang;
                this.switchLang(lang);
            });
        });
    }

    setActiveLang(lang) {
        this.buttons.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === lang);
        });
        document.documentElement.lang = lang;
    }

    switchLang(lang) {
        if (lang === this.currentLang) return;

        this.currentLang = lang;
        localStorage.setItem('nrg-lang', lang);
        this.setActiveLang(lang);

        // Trigger language change event
        document.dispatchEvent(new CustomEvent('langChange', { detail: { lang } }));

        // In a real app, this would reload translations or redirect
        // For now, we'll just reload the page
        // window.location.reload();
    }
}

// ============================================
// Back to Top
// ============================================

class BackToTop {
    constructor() {
        this.button = document.getElementById('backToTop');
        this.init();
    }

    init() {
        if (!this.button) return;

        // Scroll handler
        window.addEventListener('scroll', utils.throttle(() => {
            this.toggleVisibility();
        }, 100));

        // Click handler
        this.button.addEventListener('click', () => {
            this.scrollToTop();
        });
    }

    toggleVisibility() {
        if (window.scrollY > 500) {
            this.button.classList.add('visible');
        } else {
            this.button.classList.remove('visible');
        }
    }

    scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
}

// ============================================
// Smooth Scroll
// ============================================

class SmoothScroll {
    constructor() {
        this.init();
    }

    init() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                const href = anchor.getAttribute('href');
                if (href === '#') return;

                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    const headerHeight = document.getElementById('header')?.offsetHeight || 0;
                    const targetPosition = target.getBoundingClientRect().top + window.scrollY - headerHeight - 20;

                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }
}

// ============================================
// Video Background
// ============================================

class VideoBackground {
    constructor() {
        this.video = document.querySelector('.hero-video');
        this.init();
    }

    init() {
        if (!this.video) return;

        // Ensure video plays
        this.video.play().catch(() => {
            // If autoplay fails, show poster
            console.log('Video autoplay prevented');
        });

        // Pause video when not in viewport (performance)
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.video.play();
                } else {
                    this.video.pause();
                }
            });
        }, { threshold: 0 });

        observer.observe(this.video);
    }
}

// ============================================
// Form Validation (for Partner Form)
// ============================================

class FormValidator {
    constructor(formSelector) {
        this.form = document.querySelector(formSelector);
        this.init();
    }

    init() {
        if (!this.form) return;

        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            if (this.validate()) {
                this.submit();
            }
        });

        // Real-time validation
        this.form.querySelectorAll('input, textarea, select').forEach(field => {
            field.addEventListener('blur', () => {
                this.validateField(field);
            });
        });
    }

    validate() {
        let isValid = true;
        this.form.querySelectorAll('[required]').forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateField(field) {
        const value = field.value.trim();
        let isValid = true;
        let message = '';

        // Required check
        if (field.hasAttribute('required') && !value) {
            isValid = false;
            message = "Це поле обов'язкове";
        }

        // Email check
        if (field.type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                isValid = false;
                message = 'Введіть коректний email';
            }
        }

        // Phone check
        if (field.type === 'tel' && value) {
            const phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
            if (!phoneRegex.test(value.replace(/\s/g, ''))) {
                isValid = false;
                message = 'Введіть коректний номер телефону';
            }
        }

        // Update field state
        this.setFieldState(field, isValid, message);
        return isValid;
    }

    setFieldState(field, isValid, message) {
        const wrapper = field.closest('.form-group');
        if (!wrapper) return;

        wrapper.classList.toggle('error', !isValid);
        
        let errorEl = wrapper.querySelector('.error-message');
        if (!isValid && message) {
            if (!errorEl) {
                errorEl = document.createElement('span');
                errorEl.className = 'error-message';
                wrapper.appendChild(errorEl);
            }
            errorEl.textContent = message;
        } else if (errorEl) {
            errorEl.remove();
        }
    }

    submit() {
        const formData = new FormData(this.form);
        const data = Object.fromEntries(formData);
        
        // Collect categories from checkboxes
        const categories = [];
        this.form.querySelectorAll('input[name="categories"]:checked').forEach(cb => {
            categories.push(cb.value);
        });
        
        // Show loading state
        const submitBtn = this.form.querySelector('[type="submit"]');
        const originalHTML = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Відправка...';

        // Prepare data for API
        const apiData = {
            company_name: data.companyName || '',
            contact_name: data.contactName || '',
            phone: data.phone || '',
            email: data.email || '',
            city: data.city || '',
            business_type: data.businessType || '',
            categories: categories,
            message: data.message || ''
        };

        // Try to send to API, fallback to demo mode
        fetch('http://localhost:8000/api/partner-application', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(apiData)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                this.form.reset();
                this.showSuccess();
            } else {
                this.showError(result.message || 'Помилка при відправці');
            }
        })
        .catch(error => {
            // Demo mode - simulate success when API is unavailable
            console.log('Demo mode: API unavailable, simulating success');
            console.log('Form data:', apiData);
            this.form.reset();
            this.showSuccess();
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalHTML;
        });
    }

    showSuccess() {
        // Create success message
        const successMsg = document.createElement('div');
        successMsg.className = 'form-success';
        successMsg.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <p>Дякуємо! Ваша заявка успішно відправлена. Ми зв'яжемося з вами найближчим часом.</p>
        `;
        
        this.form.appendChild(successMsg);
        
        setTimeout(() => {
            successMsg.remove();
        }, 5000);
    }

    showError(message) {
        // Create error message
        const errorMsg = document.createElement('div');
        errorMsg.className = 'form-error';
        errorMsg.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <p>${message}</p>
        `;
        
        this.form.appendChild(errorMsg);
        
        setTimeout(() => {
            errorMsg.remove();
        }, 5000);
    }
}

// ============================================
// Categories Dropdown
// ============================================

class CategoriesDropdown {
    constructor(selector) {
        this.dropdown = document.querySelector(selector);
        if (!this.dropdown) return;
        
        this.toggle = this.dropdown.querySelector('.categories-toggle');
        this.menu = this.dropdown.querySelector('.categories-list');
        this.checkboxes = this.dropdown.querySelectorAll('input[type="checkbox"]');
        this.placeholder = this.dropdown.querySelector('.categories-placeholder');
        
        this.init();
    }
    
    init() {
        // Toggle dropdown
        this.toggle.addEventListener('click', (e) => {
            e.preventDefault();
            this.dropdown.classList.toggle('open');
        });
        
        // Close when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.dropdown.contains(e.target)) {
                this.dropdown.classList.remove('open');
            }
        });
        
        // Update text on checkbox change
        this.checkboxes.forEach(cb => {
            cb.addEventListener('change', () => this.updateText());
        });
    }
    
    updateText() {
        const checked = Array.from(this.checkboxes).filter(cb => cb.checked);
        
        if (checked.length === 0) {
            this.placeholder.textContent = 'Оберіть категорії';
            this.placeholder.classList.remove('has-selected');
        } else if (checked.length <= 2) {
            const names = checked.map(cb => cb.closest('.category-item').querySelector('.category-text').textContent);
            this.placeholder.textContent = names.join(', ');
            this.placeholder.classList.add('has-selected');
        } else {
            this.placeholder.textContent = `Обрано: ${checked.length} категорій`;
            this.placeholder.classList.add('has-selected');
        }
    }
}

// ============================================
// Initialize Everything
// ============================================

document.addEventListener('DOMContentLoaded', () => {
    // Core components
    new Preloader();
    new Header();
    new ScrollAnimations();
    new StatsCounter();
    new BackToTop();
    new SmoothScroll();
    new VideoBackground();

    // Map
    new UkraineMap();

    // Brands
    new BrandsMarquee();

    // Language
    new LanguageSwitcher();

    // Forms (if present)
    new FormValidator('#partnerForm');
    new FormValidator('#contactForm');

    console.log('NRG-UA initialized');
});

// ============================================
// Expose to global scope if needed
// ============================================

window.NRG = {
    utils,
    Preloader,
    Header,
    ScrollAnimations,
    StatsCounter,
    UkraineMap,
    BrandsMarquee,
    LanguageSwitcher,
    BackToTop,
    FormValidator,
    CategoriesDropdown
};
